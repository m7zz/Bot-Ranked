const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const LOGS_CHANNEL_ID = '1353469195471552633'; // Substitua pelo ID do canal de logs

module.exports = {
  data: new SlashCommandBuilder()
    .setName('say')
    .setDescription('Faz o bot dizer uma frase.')
    .addStringOption(option =>
      option.setName('mensagem')
        .setDescription('A mensagem que o bot vai falar')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator), // Restrição para admins

  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: '❌ Você não tem permissão para usar este comando entrosador safado.', ephemeral: true });
    }

    const mensagem = interaction.options.getString('mensagem');
    const logChannel = interaction.guild.channels.cache.get(LOGS_CHANNEL_ID);

    // Enviar a mensagem no canal especificado
    await interaction.reply({ content: `Eu disse: ${mensagem}`, ephemeral: true });
    await interaction.channel.send(mensagem);

    // Enviar log no canal de logs
    if (logChannel) {
      logChannel.send(`📢 **Comando /say usado!**\n👤 **Usuário:** ${interaction.user.tag} (${interaction.user.id})\n📌 **Canal:** ${interaction.channel}\n📝 **Mensagem:** ${mensagem}`);
    }
  },
};
