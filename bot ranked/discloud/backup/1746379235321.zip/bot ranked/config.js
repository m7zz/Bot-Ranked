module.exports = {
  token: 'MTM0NjE5MzQ3NDUxMjQ4NjUzMQ.GE5bAd.jxDJKp4XzlFSAzbG9TaiufMDi7gskev70hMaVk', // TOken do bot burrao (se vazar vai tomar é tiro)
  clientId: '1346193474512486531', // ID do seu bot 
  guildId: '1341896792907714600', // ID do servidor
};
