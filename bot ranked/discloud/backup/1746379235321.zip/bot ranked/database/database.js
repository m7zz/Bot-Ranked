const fs = require('fs');
const path = './database.json';

let database = { players: [], captains: [], history: [] };

// Carregar os dados do arquivo
function loadDatabase() {
  try {
    if (fs.existsSync(path)) {
      const data = fs.readFileSync(path);
      database = JSON.parse(data);
    }
  } catch (error) {
    console.error('Erro ao carregar o banco de dados:', error);
  }
}

// Salvar os dados no arquivo
function saveDatabase() {
  try {
    fs.writeFileSync(path, JSON.stringify(database, null, 2));
  } catch (error) {
    console.error('Erro ao salvar o banco de dados:', error);
  }
}

// Adicionar um jogador na fila
function addPlayer(player) {
  database.players.push(player);
  saveDatabase();
}

// Obter os capitães
function getCaptains() {
  return database.captains;
}

// Definir os capitães
function setCaptains(captains) {
  database.captains = captains;
  saveDatabase();
}

// Registrar o histórico de uma partida
function addMatchToHistory(team1, team2, score1, score2) {
  const match = { team1, team2, score1, score2 };
  database.history.push(match);
  saveDatabase();
}

// Obter o histórico de partidas
function getHistory() {
  return database.history;
}

// Obter os jogadores na fila
function getPlayersInQueue() {
  return database.players;
}

module.exports = {
  loadDatabase,
  saveDatabase,
  addPlayer,
  getCaptains,
  setCaptains,
  addMatchToHistory,
  getHistory,
  getPlayersInQueue,  // Adicionamos essa função aqui
};
